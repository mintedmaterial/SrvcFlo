import { type Address, defineChain } from "viem"

export type NetworkKey = "testnet" | "mainnet"

// Sonic Mainnet (id 146)
export const SONIC_MAINNET = defineChain({
  id: 146,
  name: "Sonic",
  nativeCurrency: { name: "Sonic", symbol: "S", decimals: 18 },
  rpcUrls: { default: { http: ["https://rpc.soniclabs.com"] } },
  blockExplorers: { default: { name: "SonicScan", url: "https://sonicscan.org" } },
  contracts: {
    multicall3: {
      // typical Multicall3 deployment, replace if different on mainnet
      address: "0xcA11bde05977b3631167028862bE2a173976CA11" as Address,
    },
  },
})

// Sonic Blaze Testnet (id 57054)
export const SONIC_BLAZE_TESTNET = defineChain({
  id: 57054,
  name: "Sonic Blaze Testnet",
  nativeCurrency: { name: "Sonic", symbol: "S", decimals: 18 },
  rpcUrls: { default: { http: ["https://rpc.blaze.soniclabs.com"] } },
  blockExplorers: { default: { name: "SonicScan", url: "https://testnet.sonicscan.org" } },
  contracts: {
    multicall3: {
      address: "0xcA11bde05977b3631167028862bE2a173976CA11" as Address,
    },
  },
})

// Per-network onchain addresses.
// Fill in your Mainnet values when ready.
export const ADDRESS_BOOK: Record<
  NetworkKey,
  {
    USDC?: Address
    PAYMENT?: Address
    CREDITS_ERC1155?: Address
    CREDIT_TOKEN_ID?: bigint
    explorerBase: string
  }
> = {
  testnet: {
    USDC: "0xA4879Fed32Ecbef99399e5cbC247E533421C4eC6" as Address, // Blaze USDC
    PAYMENT: "0x0000000000000000000000000000000000000000" as Address, // TODO: set your payment contract
    CREDITS_ERC1155: "0x0000000000000000000000000000000000000000" as Address, // TODO: set your ERC-1155
    CREDIT_TOKEN_ID: 1n, // default credits token id
    explorerBase: "https://testnet.sonicscan.org",
  },
  mainnet: {
    USDC: undefined, // TODO: set mainnet USDC address when available
    PAYMENT: "0x0000000000000000000000000000000000000000" as Address, // TODO: set your payment contract
    CREDITS_ERC1155: "0x0000000000000000000000000000000000000000" as Address, // TODO: set your ERC-1155
    CREDIT_TOKEN_ID: 1n,
    explorerBase: "https://sonicscan.org",
  },
}

export function getChainConfig(network: NetworkKey) {
  return network === "testnet" ? SONIC_BLAZE_TESTNET : SONIC_MAINNET
}

export function getAddressesForNetwork(network: NetworkKey) {
  return ADDRESS_BOOK[network]
}
